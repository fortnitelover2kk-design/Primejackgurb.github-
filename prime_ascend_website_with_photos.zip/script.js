const menu=document.querySelector(".menu"), nav=document.querySelector(".nav");
if(menu)menu.addEventListener("click",()=>nav.classList.toggle("open"));
function sendForm(e){e.preventDefault();document.getElementById("formMessage").textContent="Your form is ready visually. Connect it to a form service or email address to receive real submissions.";}
