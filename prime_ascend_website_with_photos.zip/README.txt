PRIME ASCEND — WEBSITE

This version uses your uploaded Prime Ascend logo and two of your journey photos.

Files:
index.html
style.css
script.js
images/logo.jpg
images/journey-start.jpg
images/current.jpg

Starter prices:
Fat-Loss Program — $39 one-time
1-on-1 Coaching — $129/month

Replace these in index.html whenever you choose.

Socials:
Instagram: @Jackyyy44Bb
YouTube: @jackgurb
TikTok display: @jackyyy🐱🐱🐱
The TikTok button currently goes to TikTok's homepage because emoji usernames may not work reliably in URLs. Replace its href with the exact profile URL from your TikTok share button.

I did not use the uploaded clothing screenshot as a product photo because it appears to show another retailer/product listing. Add your own clothing/product photos when you have them.

To publish free with GitHub Pages, upload the files to a repository named YOURUSERNAME.github.io and enable Pages in Settings.
